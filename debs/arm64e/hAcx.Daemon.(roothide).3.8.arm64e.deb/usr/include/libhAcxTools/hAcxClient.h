
#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>

@interface hAcxClient: NSObject {
}

+ (id)sharedInstance;
+ (BOOL)isSocketServerActive;

- (NSString *)udid;
- (NSString *)temporaryFile;
- (NSData *)readDataFromFile:(NSString *)sourceFile error:(NSError **)error;
- (NSError *)writeData:(NSData *)data toFile:(NSString *)targetFile;
- (NSError *)moveFile:(NSString *)file1 toFile:(NSString *)file2;
- (NSError *)copyFile:(NSString *)file1 toFile:(NSString *)file2;
- (NSError *)symlinkFile:(NSString *)file1 toFile:(NSString *)file2;
- (NSError *)deleteFile:(NSString *)file;
- (NSDictionary *)attributesOfFile:(NSString *)file error:(NSError **)retError;
- (NSArray *)contentsOfDirectory:(NSString *)dir error:(NSError **)retError;
- (BOOL)chmodFile:(NSString *)file mode:(mode_t)mode;
- (BOOL)fileExists:(NSString *)file;
- (NSError *)createDirectory:(NSString *)dir;
- (BOOL)killTask:(NSString *)task;
- (NSError *)sqlQuery:(NSString *)dbName dbPath:(NSString *)dbPath query:(NSString *)query results:(NSArray **)results;
- (NSError *)openDB:(NSString *)dbName dbPath:(NSString *)dbPath;
- (NSError *)runCommand:(NSString *)cmd output:(NSString **)output;

- (NSError *)transcriptAudioFile:(NSString *)filename
                localeIdentifier:(NSString *)localeIdentifier
                      transcript:(NSString **)transcript;
- (NSError *)transcriptAudioFile:(NSString *)filename
                localeIdentifier:(NSString *)localeIdentifier
                      saveToFile:(NSString *)saveToFile
    postNotificationOnCompletion:(NSString *)postNotification ; // will immediatly return. listen to the notification to get notified when it's saved
- (NSError *)grantTCCAuthorization:(NSString *)service bundleIdentifier:(NSString *)bundleIdentifier;

@end
